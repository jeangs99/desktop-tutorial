function(btnEnvia){
	var nome;
	var nick;
	var idade;
	/*document.querySelector('#btnEnvia').addEventListener('click', () => {
		window.location.href = 'jogo-dados.html';	
	});*/
	alert('Funcionando');
}